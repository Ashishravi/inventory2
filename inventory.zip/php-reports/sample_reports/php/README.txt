Reports written in PHP.  
This is useful for merging data between different sources, 
pulling in data from APIs, 
and doing complex processing that is out of the scope of SQL.
