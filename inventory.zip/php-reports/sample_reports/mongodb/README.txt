Reports run in the MongoDB Shell.  mongo-client is required for these reports, but the PHP extension is not.
