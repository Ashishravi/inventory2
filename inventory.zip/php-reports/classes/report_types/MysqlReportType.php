<?php
class MysqlReportType extends PdoReportType {
	public static $default_driver = 'mysql';
}
