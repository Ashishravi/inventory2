Any template placed here will be used instead of the default template.
